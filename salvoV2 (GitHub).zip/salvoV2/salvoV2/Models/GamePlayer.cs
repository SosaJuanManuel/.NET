﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace salvoV2.Models
{
    public class GamePlayer
    {
            public long Id { get; set; }
            public DateTime JoinDate { get; set; }
            public Game Game { get; set; }
            public Player Player { get; set; }
            public long? Playerid { get; set; }
            public long? Gameid { get; set; }
            public ICollection<Ship> Ship { get; set; }
            public ICollection<Salvo> Salvos { get; set; }
            public Score GetScore()
            {
               return Player.GetScore(Game);
            }
            public GamePlayer GetOpponent()
            {
                GamePlayer enemy = Game.GamePlayer.Where(gameplayer => gameplayer.Id != Id).FirstOrDefault();
                return enemy;
            }

        public string GetGameState(List<string> ShipList, List<string> OpponentShipList)
        {
            GamePlayer enemy = GetOpponent();
            if (Ship.Count == 0)
            {
                return ("PLACE_SHIPS");
            }

            if (enemy == null)
            {
                return ("WAIT");
            }

            _ = JoinDate < enemy.JoinDate ? true : false;

            if (OpponentShipList.Count == enemy.Ship.Count && ShipList.Count == Ship.Count && Salvos.Count() == enemy.Salvos.Count() && Salvos.Count > 0)
            {
                return ("TIE");
            }



            if (ShipList.Count == Ship.Count && Salvos.Count == enemy.Salvos.Count() && Salvos.Count() > 0)
            {
                return ("LOSS");
            }

            if (OpponentShipList.Count == enemy.Ship.Count && Salvos.Count == enemy.Salvos.Count && Salvos.Count > 0)
            {

                return ("WIN");

            }
            var IsCreator = JoinDate > enemy.JoinDate ? false : true;

            if (!IsCreator && Salvos.Count() == enemy.Salvos.Count() || IsCreator && Salvos.Count() > enemy.Salvos.Count)
            {
                return ("WAIT");
            }
            return "ENTER_SALVO";
        }

    }
}
