﻿using Microsoft.EntityFrameworkCore;
using Salvo.Repositories;
using salvoV2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace salvoV2.Repositories
{
    public class PlayerRepository : RepositoryBase<Player> , IPlayerRepository
    {
        public PlayerRepository(salvoV2Context repositoryContext)
            : base(repositoryContext)
        {
            
        }
        public List<Player> GetPlayer()
        {
                return FindAll()
                .ToList();   
        }
        public Player GetOnePlayer(long? Id)
        {

            return FindAll().FirstOrDefault(p => p.Id == Id);        
        }

        public Player FindByEmail(string email)
        {
            return FindAll().FirstOrDefault(pl => pl.Email == email);
        }
        public void Save(Player player)
        {
            Create(player);
            SaveChanges();
        }
        public Player FindById(long Id)
        {
            return FindAll(source => source
            .Include(g => g.GamePlayer)
            .ThenInclude(gp => gp.Player)
            ).FirstOrDefault(g => g.Id == Id);
        }
    }

}
