﻿using salvoV2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace salvoV2.Repositories
{
    public interface IGamePlayerRepository
    {
        List<GamePlayer> GetGamePlayerList();
        List<GamePlayer> GetGamePlayerList(long? idGame);
        GamePlayer Getgameplayers(int IdGamePlayer);
        void Save(GamePlayer gameplayer);
        GamePlayer FindById(long Id);

    }
}
