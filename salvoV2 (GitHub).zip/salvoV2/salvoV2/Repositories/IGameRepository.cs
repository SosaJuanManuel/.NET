﻿using salvoV2.DTOs;
using salvoV2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace salvoV2.Repositories
{
    public interface IGameRepository
    {
        IEnumerable<Game> GetGames();
        Game GetUniqueGame(long id);
        ICollection<Game> GetScore();
        Game FindById(long Id);
    }
}
