﻿using salvoV2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace salvoV2.Repositories
{
    public interface IPlayerRepository
    {
        List<Player> GetPlayer();
        Player GetOnePlayer(long? Id);
        IQueryable<Player> FindAll();
        IQueryable<Player> FindByCondition(Expression<Func<Player, bool>> expression);
        void Create(Player entity);
        void Update(Player entity);
        void Delete(Player entity);
        Player FindByEmail(string email);
        void Save(Player player);
        Player FindById(long Id);
    }
}
