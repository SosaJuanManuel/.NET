﻿using salvoV2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using salvoV2.Controllers;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authentication;
using Salvo.Repositories;
using salvoV2.DTOs;

namespace salvoV2.Repositories
{
    public class GameRepository : RepositoryBase<Game>, IGameRepository
    {
        private readonly salvoV2Context Context;
        public GameRepository(salvoV2Context repositoryContext)
            : base(repositoryContext)
        {
            Context = repositoryContext;
        }
        public IEnumerable<Game> GetGames()
        {
            return FindAll(source => source
                   .Include(x => x.GamePlayer)
                       .ThenInclude(GamePlayer => GamePlayer.Player)
                   .Include(x => x.GamePlayer)
                       .ThenInclude(GamePlayer => GamePlayer.Ship)
                           .ThenInclude(Ship => Ship.Locations)
                   .Include(g => g.GamePlayer)
                     .ThenInclude(gp => gp.Player)
                       .ThenInclude(p => p.Score))
                .ToList();
        }
        public Game GetUniqueGame(long id)
        {
            return FindAll(source => source.Include(gp => gp.GamePlayer)
                                                .ThenInclude(p => p.Player)
                                            .Include(gp => gp.GamePlayer)
                                                .ThenInclude(sh => sh.Ship)
                                                    .ThenInclude(shlo => shlo.Locations)
                                            .Include(sc => sc.Scores)
                                            )
                .ToList()
                .FirstOrDefault(g => g.Id == id);
                                            

               
            
        }
        public ICollection<Game> GetScore()
        {
            return FindAll(source => source.Include(g => g.GamePlayer)
                                                  .ThenInclude(gp => gp.Player)
                                                  .ThenInclude(p => p.Score))
                                            .Include(x => x.GamePlayer)
                                                  .ThenInclude(y => y.Ship)
                                                      .ThenInclude(b => b.Locations)
                                                .ToList();
        }
        public Game FindById(long Id)
        {
            return FindAll(source => source
            .Include(g => g.GamePlayer)
            .ThenInclude(gp => gp.Player)
            ).FirstOrDefault(g => g.Id == Id);
        }
    }
}

