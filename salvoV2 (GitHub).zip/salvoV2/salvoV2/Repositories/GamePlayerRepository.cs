﻿using salvoV2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Salvo.Repositories;

namespace salvoV2.Repositories
{
    public class GamePlayerRepository : RepositoryBase<GamePlayer>, IGamePlayerRepository
    {
        public GamePlayerRepository(salvoV2Context repositorycontext)
           : base(repositorycontext)
        {
        }

        public GamePlayer Getgameplayers(int IdGamePlayer)
        {
            return FindAll(source => source.Include(gamePlayer => gamePlayer.Ship)
                                               .ThenInclude(ship => ship.Locations)
                                           .Include(gamePlayer => gamePlayer.Salvos)
                                               .ThenInclude(Salvos => Salvos.Locations)
                                           .Include(gamePlayer => gamePlayer.Game)
                                               .ThenInclude(game => game.GamePlayer)
                                                   .ThenInclude(gp => gp.Player)
                                           .Include(gamePlayer => gamePlayer.Game)
                                               .ThenInclude(game => game.GamePlayer)
                                                   .ThenInclude(gp => gp.Salvos)
                                                      .ThenInclude(Salvos => Salvos.Locations)
                                           .Include(gamePlayer => gamePlayer.Game)
                                               .ThenInclude(game => game.GamePlayer)
                                                   .ThenInclude(gp => gp.Ship)
                                                   .ThenInclude(ship => ship.Locations)
                                                    .Include(gamePlayer => gamePlayer.Game)
                                                        .ThenInclude(game => game.Scores)
                                           )
               .Where(gamePlayer => gamePlayer.Id == IdGamePlayer)
               .OrderBy(game => game.JoinDate)
               .FirstOrDefault();
        }
        public List<GamePlayer> GetGamePlayerList()
        {
            return FindAll(gameplayer => gameplayer
                                .Include(x => x.Game)
                                .Include(x => x.Player)
                            ).ToList();
        }
        public List<GamePlayer> GetGamePlayerList(long? idGame)
        {
            
                return FindAll().Where(r => r.Gameid == idGame).ToList();
            
        }
        public void Save(GamePlayer gameplayer)
        {
            if (gameplayer.Id == 0)
                Create(gameplayer);
            else
                Update(gameplayer);
            SaveChanges();
        }
        public GamePlayer FindById(long Id)
        {
            return FindAll(source => source
            .Include(gp => gp.Player)
            .Include(gamePlayer => gamePlayer.Ship)
                .ThenInclude(ship => ship.Locations)
            .Include(gamePlayer => gamePlayer.Game)
                .ThenInclude(game => game.GamePlayer)
                    .ThenInclude(gp => gp.Salvos)
                        .ThenInclude(Salvos => Salvos.Locations)
            .Include(gameplayer => gameplayer.Game)
              .ThenInclude(game => game.Scores)
                        
            ).Where(gp => gp.Id == Id)
             .FirstOrDefault(g => g.Id == Id);
        }
    }
}
