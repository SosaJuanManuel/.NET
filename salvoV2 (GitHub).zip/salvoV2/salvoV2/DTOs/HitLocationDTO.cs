﻿using salvoV2.Models;
using salvoV2.ModelViews;
using salvoV2.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace salvoV2.DTOs
{
       public class HitLocationDTO
        {
            public string Type { get; set; }
            public List<string> Hits { get; set; }

            public HitLocationDTO(Models.Salvo misalvo, Ship enemy)
            {
                Type = enemy.Type;
                Hits = new List<string>();

                foreach (ShipLocation locations in enemy.Locations)
                {
                    foreach (SalvoLocation location in misalvo.Locations)
                    {
                        if(location.Location == locations.Location)
                        {
                          string NewHit = location.Location;
                            Hits.Add(NewHit);
                        }
                    }
                }
            }

            public HitLocationDTO()
            {
            }
        }

    
}
