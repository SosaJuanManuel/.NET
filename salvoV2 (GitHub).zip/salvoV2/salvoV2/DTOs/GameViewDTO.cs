﻿using salvoV2.Models;
using salvoV2.ModelViews;
using salvoV2.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace salvoV2.DTOs
{

    public class GameViewDTO // DTO
    {
        public long Id { get; set; }
        public DateTime Created { get; set; }
        public List<GamePlayerView> GamePlayers { get; set; }
        public List<ShipView> Ships { get; set; }
        public List<SalvoView> Salvos { get; set; }
        public List<HitDTO> Hits { get; set; }
        public List<HitDTO> HitsOpponent { get; set; }
        private List<string> ShipList { get; set; }
        private List<string> OpponentShipList { get; set; }
        public List<string> Sunks { get; set; }
        public List<string> SunksOpponent { get; set; }
        public string GameState { get; set; }

        public GameViewDTO()
        { }

        public GameViewDTO(GamePlayer gameplayer)
        {
            Created = gameplayer.Game.CreationDate;
            Id = gameplayer.Id;

            GamePlayers = new List<GamePlayerView>();
            Ships = new List<ShipView>();
            Salvos = new List<SalvoView>();
            Hits = new List<HitDTO>();
            HitsOpponent = new List<HitDTO>();
            ShipList = new List<string>();
            OpponentShipList = new List<string>();

            foreach (var gp in gameplayer.Game.GamePlayer)
            {
                GamePlayers.Add(new GamePlayerView(gp));

                foreach (var gps in gp.Salvos)
                {
                    Salvos.Add(new SalvoView(gps));
                }
            }
            foreach (var sp in gameplayer.Ship)
            {
                Ships.Add(new ShipView(sp));
            }
            if (gameplayer.GetOpponent() != null)
            {
                foreach (var salvo in gameplayer.Salvos)
                {
                    Hits.Add(new HitDTO(salvo, gameplayer.GetOpponent()));
                }
                foreach (var salvo in gameplayer.GetOpponent().Salvos)
                {
                    HitsOpponent.Add(new HitDTO(salvo, gameplayer));
                }

                foreach (HitDTO hitsdto in Hits)
                {
                    foreach (HitLocationDTO hitslocation in hitsdto.Hits)
                    {
                        foreach (string hitlc in hitslocation.Hits)
                        {
                            OpponentShipList.Add(hitslocation.Type);
                        }

                    }
                }
                foreach (HitDTO hitsdto in HitsOpponent)
                {
                    foreach (HitLocationDTO hitslocation in hitsdto.Hits)
                    {
                        foreach (string hitlc in hitslocation.Hits)
                        {
                            ShipList.Add(hitslocation.Type);
                        }

                    }
                }
            }
            Sunks = SunkenShip(ShipList);
            SunksOpponent = SunkenShip(OpponentShipList);
            GameState = gameplayer.GetGameState(Sunks,SunksOpponent);
        }
        public List<string> SunkenShip(List<string> shiplist)
        {
            List<string> sunkenlist = new List<string>();
            int Carrier = 5;
            int Battleship = 4;
            int Submarine = 3;
            int Destroyer = 3;
            int Patroal_Boat = 2;

            foreach (string ShipType in shiplist)
            {
                switch (ShipType)
                {
                    case "Carrier":
                        Carrier--;
                        break;
                    case "BattleShip":
                        Battleship--;
                        break;
                    case "Submarine":
                        Submarine--;
                        break;
                    case "Destroyer":
                        Destroyer--;
                        break;
                    case "PatroalBoat":
                        Patroal_Boat--;
                        break;
                }
            }

            if (Carrier <= 0)
            {
                sunkenlist.Add("Carrier");
            }
            if (Battleship <= 0)
            {
                sunkenlist.Add("BattleShip");
            }
            if (Submarine <= 0)
            {
                sunkenlist.Add("Submarine");
            }
            if (Destroyer <= 0)
            {
                sunkenlist.Add("Destroyer");
            }
            if (Patroal_Boat <= 0)
            {
                sunkenlist.Add("PatroalBoat");
            }
            return sunkenlist;
        }


    }
}   
