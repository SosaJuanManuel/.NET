﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using salvoV2.Models;
using salvoV2.ModelViews;


namespace salvoV2.DTOs
{
    public class HitDTO
    {
        public long Turn { get; set; }
        public List<HitLocationDTO> Hits { get; set; }
        public HitDTO(Models.Salvo salvo, GamePlayer opponent)
        {
            Turn = salvo.Turn;
            Hits = new List<HitLocationDTO>();

            foreach (Ship ship in opponent.Ship)
            {
                Hits.Add(new HitLocationDTO(salvo, ship));
            }
        }
        public HitDTO()
        {
        }


    }

}
