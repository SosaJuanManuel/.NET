﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace salvoV2.DTOs
{
    public class GuestPlayerDTO
    {
        public string Email { get; set; }
        public List<GameDTO> Games { get; set; }

        public GuestPlayerDTO(List<GameDTO> game, string  email)
            {
            Email = email;
            Games = game;
            }
    }
}
