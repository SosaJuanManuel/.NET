﻿using salvoV2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace salvoV2.DTOs
{
    public class PlayerPasswordDTO
    {
        public long Id { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public PlayerPasswordDTO(Player player)
        {
            Id = player.Id;
            Email = player.Email;
        }

        public PlayerPasswordDTO()
        {

        }
    }
    
}
