﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using salvoV2.Models;
using salvoV2.ModelViews;

namespace salvoV2.DTOs
{
    public class GameDTO
    {
        public long Id { get; set; }
        public DateTime? Created { get; set; }
        public List<GamePlayerDTO> GamePlayers { get; set; }

        public GameDTO(Game game)
        {
            Created = game.CreationDate;
            Id = game.Id;

            GamePlayers = new List<GamePlayerDTO>();

            foreach (var gameplayer in game.GamePlayer)
            {
                GamePlayers.Add(new GamePlayerDTO(gameplayer));
            }
        }


    }
}
