﻿using salvoV2.Models;
using salvoV2.ModelViews;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace salvoV2.Repositories
{
    public class SalvoView
    {
        public int Turn { get; set; }
        public long Id { get; set; }
        public PlayerView Player { get; set; }
        public ICollection<SalvoLocationView> Locations { get; set; }
        public SalvoView(Models.Salvo salvo)
        {
            Turn = salvo.Turn;
            Id = salvo.Id;
            Player = new PlayerView (salvo.GamePlayer.Player);
            Locations = new List<SalvoLocationView>();

            foreach (var location in salvo.Locations)
            {
                Locations.Add(new SalvoLocationView(location));
            }
        }
        public SalvoView()
        {

        }
    }
}
