﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using salvoV2.Models;

namespace salvoV2.Models
{
    public class PlayerView
    {
        public long Id { get; set; }
        public string Email { get; set; }
        public PlayerView(Player player)
        {
            Id = player.Id;
            Email = player.Email;
        }
        public PlayerView()
        { }
    }
}
