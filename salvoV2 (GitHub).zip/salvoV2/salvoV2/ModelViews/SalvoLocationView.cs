﻿using salvoV2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace salvoV2.ModelViews
{
    public class SalvoLocationView
    {       
            public long Id { get; set; }
            public string Location { get; set; }
            public SalvoLocationView(SalvoLocation salvolocation)
            {
                Id = salvolocation.Id;
                Location = salvolocation.Location;
            }
        public SalvoLocationView()
        {
                
        }
    }
}
