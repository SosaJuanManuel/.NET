﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using salvoV2.Models;

namespace salvoV2.Models
{
    public class GamePlayerView
    {
        public long Id { get; set; }
        public  PlayerView Player { get; set; }
        public GamePlayerView(GamePlayer gameplayer)
        {
            Id = gameplayer.Id;
            Player = new PlayerView(gameplayer.Player);
        }
    }
    public class GamePlayerDTO
    {
        public long Id { get; set; }
        public PlayerView Player { get; set; }
        public double? Point { get; set; }
        public GamePlayerDTO(GamePlayer gameplayer)
        {
            Id = gameplayer.Id;
            Player = new PlayerView(gameplayer.Player);
            Point = gameplayer.Player.GetScore(gameplayer.Game) != null ? gameplayer.Player.GetScore(gameplayer.Game).Point : null;
        }
        public GamePlayerDTO()
        {

        }
    }
   
}

