﻿using salvoV2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace salvoV2.ModelViews
{
    public class ShipLocationView
    {
        public long Id { get; set; }
        public string Location { get; set; }
        public ShipLocationView(ShipLocation shipLocation)
        {
            Id = shipLocation.Id;
            Location = shipLocation.Location;
        }
        public ShipLocationView()
        {

        }
    }
}
