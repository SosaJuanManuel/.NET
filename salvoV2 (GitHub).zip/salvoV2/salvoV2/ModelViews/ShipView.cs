﻿using salvoV2.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace salvoV2.ModelViews
{
    public class ShipView
    {
            public long Id { get; set; }
            public string Type { get; set; }
            public ICollection<ShipLocationView> Locations { get; set; }
            public ShipView(Ship ship)
            {
                Id = ship.Id;
                Type = ship.Type;
                Locations = new List<ShipLocationView>();

                foreach (var location in ship.Locations)
                {
                    Locations.Add(new ShipLocationView(location));
                }
            }
        public ShipView()
        {

        }
    }
}
