﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace salvoV2.Migrations
{
    public partial class FinalScore : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
