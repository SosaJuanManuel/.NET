﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using salvoV2.Models;

namespace salvoV2.Models
{
    public class salvoV2Context : DbContext
    {
        public salvoV2Context (DbContextOptions<salvoV2Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Player> Players { get; set; }

        public virtual DbSet<salvoV2.Models.Game> Games { get; set; }

        public virtual DbSet<salvoV2.Models.GamePlayer> GamePlayers { get; set; }
        public virtual DbSet<salvoV2.Models.Ship> Ships { get; set; }
        public virtual DbSet<salvoV2.Models.ShipLocation> ShipLocations { get; set; }
        public virtual DbSet<Salvo> Salvos { get; set; }
        public virtual DbSet<SalvoLocation> Salvolocations { get; set; }
        public virtual DbSet<Score> Score { get; set; }
    }
}
