﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using salvoV2.DTOs;
using salvoV2.Models;
using salvoV2.Repositories;

namespace salvoV2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class PlayersController : ControllerBase
    {
        readonly IPlayerRepository playerRepository;
        public PlayersController(IPlayerRepository repositoryp)
        {
            playerRepository =  repositoryp;
        }
        // GET: api/Players/1
        //[HttpGet]
        [HttpGet(Name = "GetPlayer")]
        public IActionResult GetPlayer(long Id)
        {
            return Ok(playerRepository.GetPlayer());
        }
        [HttpPost]
        public ActionResult Post([FromBody] PlayerPasswordDTO player)
        {
            try
            {
                if (player.Email == null && player.Password == null||player.Email == "" || player.Password == "")
                {
                    return StatusCode(403, "datos invalidos");
                }
                if (playerRepository.FindByEmail(player.Email) != null)
                {
                    return StatusCode(403, "Email en uso");
                }
                Player newPlayer = new Player { Email = player.Email, Password = player.Password };

                playerRepository.Save(newPlayer);
                return StatusCode(201, newPlayer);
            }

            catch (Exception )
            {
                return StatusCode(500, "Internal server error");

            }
        }

    }


    
}