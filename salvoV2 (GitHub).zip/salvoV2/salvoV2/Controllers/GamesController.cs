﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using salvoV2.DTOs;
using salvoV2.Models;
using salvoV2.Repositories;

namespace salvoV2.Controllers
{
    //[Route("api/[controller]")]
    [Route("api/games")]
    [ApiController]
    [Authorize]
    public class GamesController : ControllerBase
    {

        readonly IGameRepository gameRepository;
        readonly IPlayerRepository playerRepository;
        readonly IGamePlayerRepository gamePlayerRepository;
        string Email;
        public GamesController(IGameRepository repository, IPlayerRepository repository2, IGamePlayerRepository repository3)
        {
            gameRepository = repository;
            playerRepository = repository2;
            gamePlayerRepository = repository3;
        }
        // GET: api/games
        [HttpGet]
        [AllowAnonymous]
        public IActionResult GetGames()
        {
            var listgamesDB = gameRepository.GetGames();
            List<GameDTO> listGameView = new List<GameDTO>();

            foreach (var game in listgamesDB)
            {
                var gameView = new GameDTO(game);
                listGameView.Add(gameView);
            }
            Email = User.FindFirst("Player") != null ? User.FindFirst("Player").Value : "Guest";
            return Ok(new GuestPlayerDTO(listGameView, Email));
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult Get(long id)
        {
            return Ok(gameRepository.GetUniqueGame(id));
        }

        [HttpPost]
        public IActionResult Post()
        {
            Email = User.FindFirst("Player") != null ? User.FindFirst("Player").Value : "Guest";
            var aux = playerRepository.FindByEmail(Email);
            GamePlayer newPlayer = new GamePlayer
            {
                JoinDate = DateTime.Now,
                Playerid = aux.Id,
                Game = new Game { CreationDate = DateTime.Now},


            };

            gamePlayerRepository.Save(newPlayer);
            return StatusCode(201, newPlayer.Id);


        }

        [HttpPost("{id}/Players")]
        public IActionResult Post(long Id)
        {
            Email = User.FindFirst("Player") != null ? User.FindFirst("Player").Value : "Guest";
            var p = playerRepository.FindByEmail(Email);
            var g = gameRepository.FindById(Id);


                if (g == null)
                {
                    return StatusCode(403, "Error. Juego inexistente.");
                }

                if (g.GamePlayer.First().Player.Id == p.Id)
                {
                    return StatusCode(403, "Error. El jugador ya se encuentra en la partida.");
                }
                if (g.GamePlayer.Count() >= 2)
                {
                    return StatusCode(403, "Juego Lleno.");
                }

            GamePlayer newPlayer = new GamePlayer
            {
                JoinDate = DateTime.Now,
                Playerid = p.Id,
                Gameid= Id
            };

            gamePlayerRepository.Save(newPlayer);
            return StatusCode(201, newPlayer.Id);

        }

        
    }
    
}
