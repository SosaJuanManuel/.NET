﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using salvoV2.DTOs;
using salvoV2.Models;
using salvoV2.ModelViews;
using salvoV2.Repositories;

namespace salvoV2.Controllers
{

    //[Route("api/[controller]")]
    [Route("api/gamePlayers")]
    [ApiController]
    [Authorize("PlayerOnly")]
    public class GamePlayersController : ControllerBase
    {
        readonly IGamePlayerRepository _gameplayerRepository;
        readonly IGameRepository _gameRepository;
        readonly IPlayerRepository _playerRepository;
        readonly IScoreRepository _scoreRepository;
        string Email;
        public GamePlayersController(IGamePlayerRepository gameplayerRepository, IGameRepository gameRepository, IPlayerRepository playerRepository, IScoreRepository scoreRepository)
        {
            _gameplayerRepository = gameplayerRepository;
            _gameRepository = gameRepository;
            _playerRepository = playerRepository;
            _scoreRepository = scoreRepository;
        }

        public IGameRepository GameRepository => _gameRepository;

        // GET: api/GamePlayers
        [HttpGet]
        public IActionResult GetGamePlayers()
        {
            return Ok(_gameplayerRepository.GetGamePlayerList());
        }
        //GET: api/GamePlayers/1
        [HttpGet("{id}")]
        public IActionResult Getgameplayers(int id)
        {

            Email = User.FindFirst("Player") != null ? User.FindFirst("Player").Value : "Guest";
            var gpActual = _gameplayerRepository.Getgameplayers(id);
            var gameview = new GameViewDTO(gpActual);
            var gamestate = gameview.GameState;
            if (gpActual == null)
            {
                return StatusCode(403, "FORBIDEN");
            }
            if (gpActual.Player.Email == Email)
            {
                if (gamestate == "WIN" && gpActual.Game.Scores.Count() == 0)
                {
                    Score scorehost = new Score()
                    {
                        GameId = gpActual.Gameid,
                        PlayerId = gpActual.Playerid,
                        Point = 1.0,
                        FinishDate = DateTime.Now
                    };

                    _scoreRepository.Save(scorehost);

                    Score scorerival = new Score()
                    {
                        GameId = gpActual.Gameid,
                        PlayerId = gpActual.GetOpponent().Playerid,
                        Point = 0.0,
                        FinishDate = DateTime.Now
                    };
                    _scoreRepository.Save(scorerival);        
                }
                if (gamestate == "LOSS" && gpActual.Game.Scores.Count() == 0)
                {
                    Score scorehost = new Score()
                    {
                        GameId = gpActual.Gameid,
                        PlayerId = gpActual.Playerid,
                        Point = 0.0,
                        FinishDate = DateTime.Now
                    };

                    _scoreRepository.Save(scorehost);

                    Score scorerival = new Score()
                    {
                        GameId = gpActual.Gameid,
                        PlayerId = gpActual.GetOpponent().Playerid,
                        Point = 1.0,
                        FinishDate = DateTime.Now
                    };
                    _scoreRepository.Save(scorerival);
                }

                if (gamestate == "TIE" && gpActual.Game.Scores.Count() == 0)
                {
                    Score scorehost = new Score()
                    {
                        GameId = gpActual.Gameid,
                        PlayerId = gpActual.Playerid,
                        Point = 0.5,
                        FinishDate = DateTime.Now
                    };

                    _scoreRepository.Save(scorehost);

                    Score scorerival = new Score()
                    {
                        GameId = gpActual.Gameid,
                        PlayerId = gpActual.GetOpponent().Playerid,
                        Point = 0.5,
                        FinishDate = DateTime.Now
                    };
                    _scoreRepository.Save(scorerival);
                }

            }

            return Ok(gameview);
        }

        

        //Get: api/GamePlayers/{id}/ships
        [HttpPost("{id}/Ships")]
        public IActionResult PutShips(int id, [FromBody] List<Ship> ship)
        {
            GamePlayer gp = _gameplayerRepository.FindById(id);
            Email = User.FindFirst("Player") != null ? User.FindFirst("Player").Value : "Guest";
            Player p = _playerRepository.FindByEmail(Email);
            
            if (gp == null)
            {
                return StatusCode(403, "No existe el juego");
            }
            if (gp.Playerid != p.Id)
            {
                return StatusCode(403, "El usuario no se encuentra en el juego");
            }
            if(gp.Ship.Count != 0)
            {
                return StatusCode(403, " ya estan posicionados los barcos");
            }

            gp.Ship = ship;
            _gameplayerRepository.Save(gp);
            return StatusCode(201, "Se posicionaron los barcos");
        }

        //Get: api/GamePlayers/{id}/salvos
        [HttpPost("{id}/salvos")]
        public IActionResult Shoot(long id, [FromBody] SalvoView salvodto)
        {
            GamePlayer gp = _gameplayerRepository.FindById(id);
            Email = User.FindFirst("Player") != null ? User.FindFirst("Player").Value : "Guest";
            Player p = _playerRepository.FindByEmail(Email);
            //Game g = _gameRepository.FindById(id);
            var Enemy = gp?.GetOpponent();
            
            if (gp == null)
            {
                return StatusCode(403, "No existe el juego");
            }

            if(Enemy == null)
            {
                return StatusCode(403, "No existe oponente");
            }

            var IsCreator = gp.JoinDate > Enemy.JoinDate ? false : true;

            if (gp.Playerid != p.Id)
            {
                return StatusCode(403, "El usuario no se encuentra en el juego");
            }

            if (!IsCreator && gp.Salvos.Count() == Enemy.Salvos.Count() || IsCreator && gp.Salvos.Count() > Enemy.Salvos.Count)
            {
                return StatusCode(403, "No se puede adelantar el turno");
            }

            Models.Salvo sl = new Models.Salvo
            {
                Turn = gp.Salvos.Count() == 0 ? 1 : gp.Salvos.Count() + 1,
                GamePlayerId = gp.Id,
                Locations = new List<SalvoLocation>()
            };
            foreach (SalvoLocationView salvoLocationView in salvodto.Locations)
            {
                SalvoLocation salvoLocation = new SalvoLocation
                {
                    Location = salvoLocationView.Location
                };
                sl.Locations.Add(salvoLocation);

            }
            gp.Salvos.Add(sl);
            _gameplayerRepository.Save(gp);

            return StatusCode(201, "ok");
        }
    }
}
